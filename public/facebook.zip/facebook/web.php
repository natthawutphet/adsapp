<?php
include "admin/db.php";

function saveUserIP($userIp) {
    global $conn; // อ้างอิง $conn จาก global scope ถ้า db.php ถูก include แล้ว
    $stmt = $conn->prepare("INSERT INTO ipb(uipb) VALUES (?)");
    $stmt->execute([$userIp]);
}

$stmt = $conn->query("SELECT * FROM weburl");
$stmt->execute();
$rows = $stmt->fetchAll(); 

if(!$rows) {
    // Handle the case where no URLs are found, maybe redirect to a default page or show an error.
    header("Location: $urls");
    exit;
} else {
    // Assuming you want to redirect to the last URL fetched
    $lastRow = end($rows); // Get the last element of the array
    $urls = $lastRow['weburls'];
    header("Location: $urls");
    exit;
}
